package org.example;

public class ProductoDescuento extends Producto {
    private double porcentajeDescuento;

    public ProductoDescuento(int codigo, String nombre, double precio, int cantidad, double porcentajeDescuento) {
        super(codigo, nombre, precio, cantidad);
        this.porcentajeDescuento = porcentajeDescuento;
    }

    public double getPorcentajeDescuento() {
        return this.porcentajeDescuento;
    }

    public void setPorcentajeDescuento(double porcentajeDescuento) {
        this.porcentajeDescuento = porcentajeDescuento;
    }

    @Override
    public double getPrecioFinal() {
        return super.getPrecio() * (1 - porcentajeDescuento);
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("Producto con Descuento");
        System.out.println("Código: " + getCodigo());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Precio Original: " + getPrecio());
        System.out.println("Descuento: " + (porcentajeDescuento * 100) + "%");
        System.out.println("Precio Final: " + getPrecioFinal());
        System.out.println("Cantidad: " + getCantidad());
    }
}

