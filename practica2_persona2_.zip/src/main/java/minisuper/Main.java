package org.minimarket;


import java.util.Scanner;

// Clase para probar la lógica de inventario y carrito sin interfaz gráfica
public class Main {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();
        Carrito carrito = new Carrito();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bienvenido al Minisúper");

        boolean continuar = true;
        while (continuar) {
            System.out.println("\nProductos disponibles:");
            for (Producto p : inventario.getListaProductos()) {
                System.out.println(p.getCodigo() + " - " + p.getNombre() + " (₡" + p.getPrecioFinal() + ") - Stock: " + p.getCantidad());
            }

            System.out.print("Ingrese el código del producto a agregar (o 0 para salir): ");
            int codigo = scanner.nextInt();
            if (codigo == 0) {
                continuar = false;
                break;
            }

            Producto producto = inventario.buscarProductoPorCodigo(codigo);
            if (producto == null) {
                System.out.println("Producto no encontrado.");
                continue;
            }

            System.out.print("Ingrese la cantidad: ");
            int cantidad = scanner.nextInt();

            carrito.agregarProducto(producto, cantidad);
        }

        System.out.println("\nResumen del carrito:");
        carrito.mostrarCarrito();
        scanner.close();
    }
}