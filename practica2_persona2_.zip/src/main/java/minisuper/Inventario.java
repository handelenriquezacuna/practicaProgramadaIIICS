package org.minimarket;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Esta clase se encarga de manejar los productos disponibles en el minisúper
public class Inventario {
    private List<Producto> listaProductos;
    private Map<Integer, Producto> mapaProductos;

    public Inventario() {
        listaProductos = new ArrayList<>();
        mapaProductos = new HashMap<>();
        inicializarProductos(); // Agregamos productos de ejemplo
    }

    // Método para agregar productos por defecto al inventario
    private void inicializarProductos() {
        Producto arroz = new Producto(1, "Arroz", 1000, 10);
        Producto leche = new ProductoDescuento(2, "Leche", 1200, 8, 0.15); // 15% de descuento
        Producto frijoles = new Producto(3, "Frijoles", 800, 5);

        agregarProducto(arroz);
        agregarProducto(leche);
        agregarProducto(frijoles);
    }

    public void agregarProducto(Producto producto) {
        listaProductos.add(producto);
        mapaProductos.put(producto.getCodigo(), producto);
    }

    public Producto buscarProductoPorCodigo(int codigo) {
        return mapaProductos.get(codigo);
    }

    public List<Producto> getListaProductos() {
        return listaProductos;
    }
}