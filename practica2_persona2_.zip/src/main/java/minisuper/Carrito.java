package org.minimarket;


import java.util.ArrayList;
import java.util.List;

// Esta clase representa el carrito de compras del cliente
public class Carrito {
    private List<ItemCarrito> items;

    public Carrito() {
        items = new ArrayList<>();
    }

    // Agrega un producto al carrito si hay stock suficiente
    public boolean agregarProducto(Producto producto, int cantidad) {
        if (producto.getCantidad() >= cantidad) {
            producto.reducirStock(cantidad); // Descontamos del inventario
            items.add(new ItemCarrito(producto, cantidad));
            return true;
        } else {
            System.out.println("No hay suficiente stock para " + producto.getNombre());
            return false;
        }
    }

    // Calcula el total de la compra considerando descuentos si existen
    public double calcularTotal() {
        double total = 0;
        for (ItemCarrito item : items) {
            total += item.getProducto().getPrecioFinal() * item.getCantidad();
        }
        return total;
    }

    public void mostrarCarrito() {
        for (ItemCarrito item : items) {
            System.out.println(item.getCantidad() + " x " + item.getProducto().getNombre() +
                               " = " + item.getProducto().getPrecioFinal() * item.getCantidad());
        }
        System.out.println("Total a pagar: " + calcularTotal());
    }
}