package org.minimarket;


public abstract class ProductoBase {
    public abstract double getPrecioFinal();
    public abstract void mostrarDetalles();
}